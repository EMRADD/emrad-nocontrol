local lastZ = nil
local isAirborne = false

CreateThread(function()
    while true do
        Wait(0)

        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)
            if GetPedInVehicleSeat(veh, -1) == ped then
                local isInAir = not IsVehicleOnAllWheels(veh)

                -- Havadaysa kontrol kilitle
                if isInAir then
                    isAirborne = true
                    if lastZ == nil then
                        lastZ = GetEntityCoords(veh).z
                    end

                    DisableControlAction(0, 59, true)
                    DisableControlAction(0, 60, true)
                elseif isAirborne then
                    local currentZ = GetEntityCoords(veh).z
                    local fallDistance = lastZ - currentZ

                    if fallDistance >= Config.MinFallToExplode then
                        AddExplosion(GetEntityCoords(veh), 2, 1.0, true, false, 1.0)
                        SetVehicleEngineHealth(veh, -4000.0)
                    elseif fallDistance >= Config.MinFallToDamage then
                        SetVehicleEngineHealth(veh, 100.0)
                    end

                    lastZ = nil
                    isAirborne = false
                end
            end
        end
    end
end)
