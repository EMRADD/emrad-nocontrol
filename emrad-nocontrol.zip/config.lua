Config = {}

-- Düşüş sonrası hasar sistemleri
Config.MinFallToDamage = 10.0      -- Minimum metre düşüş (motor hasarı)
Config.MinFallToExplode = 18.0     -- Minimum metre düşüş (araç patlar)
