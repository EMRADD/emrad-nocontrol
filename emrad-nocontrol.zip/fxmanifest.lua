fx_version 'cerulean'
game 'gta5'

author 'emrad'
description 'No vehicle air control & fall damage system'
version '1.0.0'

client_script 'client.lua'
shared_script 'config.lua'
